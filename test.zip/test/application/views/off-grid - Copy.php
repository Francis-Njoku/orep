<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Orep - Off-grid Renewable Energy Project</title>
    <!-- core CSS -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/animate.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/owl.carousel.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/owl.transitions.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/prettyPhoto.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/main.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/responsive.css')?>" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="<?php echo base_url('assets/js/html5shiv.js')?>"></script>
    <script src="<?php echo base_url('assets/js/respond.min.js')?>"></script>
    <![endif]-->
    <link rel="shortcut icon" href="<?php echo base_url('assets/images/ico/favicon.png')?>">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url('assets/images/ico/favicon.png')?>">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url('assets/images/ico/favicon.png')?>">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url('assets/images/ico/favicon.png')?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo base_url('assets/images/ico/favicon.png')?>">
</head><!--/head-->

<body id="home" class="homepage">


<header id="top-header" class="navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <!-- responsive nav button -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- /responsive nav button -->

            <!-- logo -->
            <div class="navbar-brand">
                <a class="smooth-scroll" data-section="#home" href="#home" >
                    <img height="80px" src="<?php echo base_url('assets/images/logo-real.png')?>" alt="logo">
                </a>
            </div>
            <!-- /logo -->
        </div>

        <!-- main nav -->
        <nav class="collapse navbar-collapse navbar-right" role="navigation">
            <div class="main-menu">
                <ul id="nav" class="nav navbar-nav">
                    <li class="scroll"><a href="#home" data-section="#home">Home</a></li>
                    <li class="scroll"><a href="#about" data-section="#about">About</a></li>
                    <li class="scroll"><a href="#features" data-section="#features">Feature</a></li>
                    <li class="scroll"><a href="#cta2" data-section="#cta2">How it Works</a></li>
                    <li class="scroll"><a href="#why-modular" data-section="#why-modular">Why Modular</a></li>
                    <li class="scroll"><a href="#opportunity" data-section="#opportunity">Opportunity</a></li>
                    <li class="scroll"><a href="#contact-area" data-section="#contact-area">Contact</a></li>
                </ul>
            </div>
        </nav>
        <!-- /main nav -->

    </div>
</header>

<section id="main-slider">
    <div class="owl-carousel">
        <div class="item" style="background-image: url(<?php echo base_url('assets/images/back1.jpg')?>);">
            <div class="slider-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="carousel-content text-center">
                                <h2>OFF-GRID RENEWABLE <span>ENERGY</span> PROJECT.</h2>
                                <p> </p>
                                <a class="btn btn-primary btn-lg" href="#features" data-section="#features">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--/.item-->
        <div class="item" style="background-image: url(<?php echo base_url('assets/images/back3.jpg')?>);">
            <div class="slider-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="carousel-content text-center">

                                <h2>CONNECTING OFF-GRID <span>COMMUNITIES</span></h2>
                                <a class="btn btn-primary btn-lg" href="#features" data-section="#features">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--/.item-->
        <div class="item" style="background-image: url(<?php echo base_url('assets/images/back2.jpg')?>);">
            <div class="slider-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="carousel-content text-center">
                                <h2>CONNECTING OFF-GRID <span>COMMUNITIES</span></h2>
                                <a class="btn btn-primary btn-lg" href="#features" data-section="#features">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--/.item-->

    </div><!--/.owl-carousel-->
</section><!--/#main-slider-->

<section id="about">
    <div class="container">

        <div class="section-header">
            <h2 class="section-title text-center wow fadeInDown">WELCOME TO OUR COMPANY</h2>
            <p class="text-center wow fadeInDown">A Social impact project aimed at providing affordable and reliable energy
                sources to rural communities across Nigeria to power public infrastructures (schools and hospitals), small
             households and farmlands</p>
        </div>

        <div class="row">


            <div class="col-sm-6 wow fadeInRight">
                <h3 class="column-title">AIM</h3>
                <p>This is aimed at advancing human achievement in rural communities through access to electricity thereby
                having a significant impact on the quality of health services, education, and access to information and communication
                technology</p>


                <a class="btn btn-primary" href="#">Discover Us</a>

            </div>
            <div class="col-sm-6 wow fadeInLeft">
                <img class="img-responsive side-image-orep" src="<?php echo base_url('assets/images/homes2.jpg')?>" alt="power">
            </div>
        </div>
    </div>
</section><!--/#about-->



<section id="features">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title2 text-center wow fadeInDown">Model</h2>
            <p class=" text-center wow fadeInDown text-center-orep" style="color: white;"> OREP is a Social Enterprise model implementing joint social impact
                projects in underserved rural communities.</p> <hr>
        </div>
        <div class="row">
            <div class="col-md-12">
                <img class="img-responsive" src="<?php echo base_url('assets/images/content.jpg')?>" alt="off-grid renewable energy project">
            </div>

        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="row">
            <div class="col-md-5 side-image-orep2">
                <h1 class="fund-orep" align="center">
                    Project Funding
                </h1>
                <p align="center">
                <img src="<?php echo base_url('assets/images/funding-project.png')?>" class="img-responsive orep-image" alt="funding">
                </p>
                <p align="center">
                    The project is expected to be implemented ith social impact investment funding.
                </p>

            </div>
            <div class="col-md-2">

            </div>
            <div class="col-md-5 side-image-orep2">
                <h1 class="fund-orep" align="center">
                    Value Proposition
                </h1>
                <p align="center">
                    <img src="<?php echo base_url('assets/images/climb.png')?>" class="img-responsive orep-image" alt="value infrastructure">
                </p>
                <p align="center">
                    The modular plant upon completion will provide the needed electricity to rural communities to enable
                    them power their public infrastructures, homes and farmlands.
                </p>

            </div>
        </div>
    </div>
</section>
<section id="cta2">
    <div class="container">
        <div class="text-center">
            <h2 class="wow fadeInUp" data-wow-duration="300ms" data-wow-delay="0ms">HOW IT WORKS </h2>
            <p class="wow fadeInUp">
                <img src="<?php echo base_url('assets/images/how-it-works.jpg')?>" class="img-responsive orep-image" alt="value infrastructure">

            </p>
            <!--<p class="wow fadeInUp" data-wow-duration="300ms" data-wow-delay="100ms">Mauris pretium auctor quam. Vestibulum et nunc id nisi fringilla <br />iaculis. Mauris pretium auctor quam.</p>
            <p class="wow fadeInUp" data-wow-duration="300ms" data-wow-delay="200ms"><a class="btn btn-primary btn-lg" href="#">Get It Now</a></p> -->
        </div>
    </div>
</section>

<section id="why-modular">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title2 text-center wow fadeInDown">Why Modular?</h2>

        </div>
        <div class="row">
            <div class="col-md-12">
                <img class="img-responsive" src="<?php echo base_url('assets/images/why-modular.jpg')?>" alt="off-grid renewable energy project">
            </div>

        </div>
    </div>
</section>


<section id="opportunity">
    <div class="container">

        <div class="section-header">
            <h2 class="section-title text-center wow fadeInDown">HOW BIG IS THE OPPORTUNITY</h2>

        </div>

        <div class="row">


            <div class="col-sm-5 wow fadeInRight">
                <div class="side-image-orep">
                <h3 class="column-title">Population spread in Nigeria</h3>
                <p align="center">
                    <img class="img-responsive" src="<?php echo base_url('assets/images/piechart.png')?>" alt="Population Statistics">
                </p>

                <p>
                    <span class="diams-black">
                        &diams;
                    </span>
                    Rural Population = 52.2%
                </p>
                <p>
                    <span class="diams-green">
                        &diams;
                    </span>
                    Urban Population = 47.8%
                </p>
                <p class="diams-statistics">
                    Data from database: World Development Indicators
                </p>



            </div>
            </div>
            <div class="col-sm-2">

            </div>
            <div class="col-sm-5 wow fadeInRight">
                <div class="side-image-orep">
                <h3 class="column-title">Inadequacies in power generation</h3>
                    <p align="center">
                        <img class="img-responsive" src="<?php echo base_url('assets/images/barchart.jpg')?>" alt="Population Statistics">
                    </p>
                    <p>
                    <span class="diams-blue">
                        &diams;
                    </span>
                        Average
                    </p>

                    <p class="diams-statistics">
                        Source: The Nigerian Bureau of Statistics (NBS)
                    </p>



                </div>

            </div>
            <!--<div class="col-sm-6 wow fadeInLeft">
                <img class="img-responsive side-image-orep" src="<?php echo base_url('assets/images/homes2.jpg')?>" alt="power">
            </div> -->

        </div>
    </div>
</section><!--/#about-->


<section id="testimonial">
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">

                <div id="carousel-testimonial" class="carousel slide text-center" data-ride="carousel">
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <p><img class="img-circle img-thumbnail" src="images/testimonial/01.jpg" alt=""></p>
                            <h4>Louise S. Morgan</h4>
                            <small>Treatment, storage, and disposal (TSD) worker</small>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut et dolore magna aliqua. Ut enim ad minim veniam</p>
                        </div>
                        <div class="item">
                            <p><img class="img-circle img-thumbnail" src="images/testimonial/01.jpg" alt=""></p>
                            <h4>Louise S. Morgan</h4>
                            <small>Treatment, storage, and disposal (TSD) worker</small>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut et dolore magna aliqua. Ut enim ad minim veniam</p>
                        </div>
                    </div>

                    <!-- Controls -->
                    <div class="btns">
                        <a class="btn btn-primary btn-sm" href="#carousel-testimonial" role="button" data-slide="prev">
                            <span class="fa fa-angle-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="btn btn-primary btn-sm" href="#carousel-testimonial" role="button" data-slide="next">
                            <span class="fa fa-angle-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!--/#testimonial-->







<div class="container">

    <div class="row-fluid">
        <div class="span9 offset3">
            <form action="" id="contact-form" class="form-horizontal" method="post">
                <fieldset>
                    <div class="control-group">
                        <label class="control-label" for="name">Your Name</label>
                        <div class="controls">
                            <input type="text" class="input-xlarge" name="name" id="name">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="email">Email Address</label>
                        <div class="controls">
                            <input type="text" class="input-xlarge" name="email" id="email">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="subject">Subject</label>
                        <div class="controls">
                            <input type="text" class="input-xlarge" name="subject" id="subject">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="message">Your Message</label>
                        <div class="controls">
                            <textarea class="input-xlarge" name="message" id="message" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="controls">
                            <button type="submit" class="btn">Send Email</button>
                        </div>
                    </div>
                </fieldset>
            </form>
            <!-- output the results (Success or failure message from controller) -->
            <div id="results"></div>
        </div>
    </div>

</div>

<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <p class="text-center">
                    &copy; 2017 OREP. Designed and Developed by <a target="_blank" href="#" title="Xadigi">Xadigi</a>
                </p>

                <ul class="social-icons text-center">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer><!--/#footer-->




<script>
    $(document).ready(function() {
        $('#contact-form').validate({
            rules: {
                name: {
                    minlength: 2,
                    required: true
                },
                email: {
                    required: true,
                    email: true
                },
                subject: {
                    minlength: 2,
                    required: true
                },
                message: {
                    minlength: 2,
                    required: true
                }
            },
            highlight: function(element) {
                $(element).closest('.control-group').removeClass('success').addClass('error');
            },
            success: function(element) {
                element.text('OK!').addClass('valid').closest('.control-group').removeClass('error').addClass('success');
            },

            submitHandler: function( form ) {

                $.ajax({
                    url : 'welcome/process',
                    data : $('#contact-form').serialize(),
                    type: "POST",
                    success : function(data){
                        $("#contact-form").hide('slow');
                        $('#results').html(data);
                    }
                })
                return false;
            }

        });
    }); // end document.ready
</script>



<script src="<?php echo base_url('assets/js/jquery.js')?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/owl.carousel.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/mousescroll.js')?>"></script>
<script src="<?php echo base_url('assets/js/jquery.prettyPhoto.js')?>"></script>
<script src="<?php echo base_url('assets/js/jquery.isotope.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/jquery.inview.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/wow.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/main.js')?>"></script>
</body>
</html>