
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Ubenwa is saving newborn lives by enabling quick and cost-effective diagnosis of birth asphyxia from infant cry. ">

    <meta name="ROBOTS" content="INDEX, FOLLOW">
    <meta name="keywords" content="Ubenwa, asphyxia app,Stream, ai, machine learning, saving newborn, fisher foundation africa ">
    <meta name="author" content="Chima">

    <title>Off-grid Renewable Energy Project</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">

    <!-- Custom CSS -->

    <link href="<?php echo base_url('assets/css/agency.css')?>" rel="stylesheet">
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/wow.js')?>"></script>
    <script>
    new WOW().init();
    </script>
    <!-- Place in the <head>, after the three links -->


  <script type="text/javascript">

  $(document).ready(function(){

   $("#myCarousel").carousel();

});

  </script>



  <!-- Custom Fonts -->
  <link href="<?php echo base_url('assets/css/font-awesome.min.css')?>" rel="stylesheet" type="text/css">
  <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href='http://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Roboto:300' rel='stylesheet' type='text/css'>
  <!--    <link rel="stylesheet" href="css/all.css"> -->
  <link  rel="stylesheet" href="<?php echo base_url('assets/css/styles.css')?>">
   <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">


  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>

    <body id="page-top" class="index">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand page-scroll" href="#page-top"><img src="<?php echo base_url('assets/img/logo-real.png')?>" style="height:50px;"></a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="hidden">
                            <a href="#page-top"></a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#overview">Overview</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#about">Stories</a>
                        </li>
                        <li  onclick="ga('send', 'event', 'Click', 'Click', 'Team', 2);">
                            <a class="page-scroll" href="#team">Team</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#media">Media</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#contact">Contact</a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>
        <header>
            <section id="promo" class="topSection section offset-header has-pattern">
                <div class="container">
                    <div class="row">
                        <div class="overview col-md-7 col-sm-12 col-xs-12">
                            <h2 class="title">Giving hope to newborns!</h2>
                            <div class="">
                                <div class="intro-description summary">Ubenwa is saving newborn lives by enabling quick and cost-effective diagnosis of birth asphyxia from infant cry.
                                    <br> <br>
                                    <a href="#contact" class="page-scroll" >
                                      <input type="button" class="button tiny" value="Stay in touch" align="center">
                                  </a>
                              </div>
                          </div>
                      </div><!--//overview-->

                      <!--// iPhone starts -->
                      <div id ="phone" class="phone iphone iphone-black col-md-4 col-sm-12 col-xs-12 ">
                        <div class="iphone-holder phone-holder">
                            <div class="iphone-holder-inner">
                                <div class="slider flexslider">
                                    <ul class="slides">
                                        <li>
                                            <img src="img/screenshots/home.png"  alt="Ubenwa App screenshots" />
                                        </li>
                                        <li>
                                            <img src="img/screenshots/record.png"  alt="Ubenwa App screenshots" />
                                        </li>
                                        <li>
                                            <img src="img/screenshots/run.png"  alt="Ubenwa App screenshots" class=""/>
                                        </li>
                                        <li>
                                            <img src="img/screenshots/u.png"  alt="Ubenwa App screenshots" class=""/>
                                        </li>
                                        <li>
                                            <img src="img/screenshots/results.png"  alt="Ubenwa App screenshots" class=""/>
                                        </li>
                                        <li>
                                            <img src="img/screenshots/history.png"  alt="Ubenwa App screenshots" class=""/>
                                        </li>
                                    </ul><!--//slides-->
                                </div><!--//flexslider-->
                            </div><!--//iphone-holder-inner-->
                        </div><!--//iphone-holder-->
                    </div><!--//iphone-->
                    <!--// iPhone ends -->
                </div><!--//row-->
            </div><!--//container-->
        </section><!--//promo-->
    </header>
    <section id="showphone" class="topSection section offset-header has-pattern">
        <div class="container">
            <div class="row">
                <!--// iPhone starts -->
                <div class="phone iphone iphone-black col-md-12 col-sm-12 col-xs-12 " align="center">
                    <div class="iphone-holder phone-holder">
                        <div class="iphone-holder-inner">
                            <div class="slider flexslider">
                                <ul class="slides">
                                    <li>
                                        <img src="img/screenshots/home.png"  alt="Ubenwa App screenshots" />
                                    </li>
                                    <li>
                                        <img src="img/screenshots/record.png"  alt="Ubenwa App screenshots" />
                                    </li>
                                    <li>
                                        <img src="img/screenshots/run.png"  alt="Ubenwa App screenshots" class=""/>
                                    </li>
                                    <li>
                                        <img src="img/screenshots/u.png"  alt="Ubenwa App screenshots" class=""/>
                                    </li>
                                    <li>
                                        <img src="img/screenshots/results.png"  alt="Ubenwa App screenshots" class=""/>
                                    </li>
                                    <li>
                                        <img src="img/screenshots/history.png"  alt="Ubenwa App screenshots" class=""/>
                                    </li>
                                </ul><!--//slides-->
                            </div><!--//flexslider-->
                        </div><!--//iphone-holder-inner-->
                    </div><!--//iphone-holder-->
                </div><!--//iphone-->
            </div>

        </div>
    </section>
    <!-- Services Section -->
    <section id="overview" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Overview</h2>
                    <h3 class="section-subheading text-muted"></h3>
                </div>
            </div>
            <div class="row text-center">
                <div class="col-md-4 wow bounceInLeft">
                    <span class="fa-stack fa-4x">
                     <img src="img/about/the_challenge.png" class="img-responsive" alt="">
                 </span>
                 <hr class="hr-overview"></hr>
                 <h4 class="service-heading">The Challenge</h4>
                 <p class="text-muted"> Birth Asphyxia is one of the top 3 causes of infant mortality in Africa, causing the death of about 1.2 million infants and severe life-long disabilities (such as cerebral palsy, deafness, and paralysis) to an equal number annually. "If newborns who have asphyxia can be detected early enough, we may be able to save their lives" - UN.</p>
             </div>
             <div class="col-md-4 wow bounceInLeft">
                <span class="fa-stack fa-4x">
                    <img src="img/about/what_we_are_doing.png" class="img-responsive" alt="">
                </span>
                <hr class="hr-overview"></hr>
                <h4 class="service-heading">What we are doing</h4>
                <p class="text-muted">We are developing a machine learning system that can take as input the infant cry, analyse the amplitude and frequency patterns in the cry, to provide instant diagnosis of birth asphyxia. The test results from our diagnostic software have shown a Sensitivity of over 86% and Specificity of 89%.</p>
            </div>
            <div class="col-md-4 wow bounceInRight">
                <span class="fa-stack fa-4x">
                    <img src="img/about/what_we_have_achieved.png" class="img-responsive" alt="">
                </span>
                <hr class="hr-overview"></hr>
                <h4 class="service-heading">What we have achieved</h4>
                <p class="text-muted">
                    For testing, our algorithm was deployed as a mobile app which harnesses the processing capabilities of smartphones to provide near-instantaneous assessment of whether or not a newborn has or is at risk of asphyxia. Ubenwa is non-invasive and can be over 95% cheaper than existing clinical alternative.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section id="about">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="section-heading">Stories</h2>
                <h3 class="section-subheading text-muted"></h3>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <ul class="timeline">
                    <li class="timeline-inverted wow slideInRight">
                        <div class="timeline-image">
                            <img class="img-circle img-responsive" src="img/about/muhc.jpeg" alt="">
                        </div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>February 2017</h4>
                                <h4 class="subheading">Ethics application to the MUHC</h4>
                            </div>
                            <div class="timeline-body">
                                <p class="text-muted"> Alongside new collaborators at the Children's Hospital of the McGill University Health Centre (MUHC), we are currently applying for ethics approval to conduct data collection there.</p>
                            </div>
                        </div>
                    </li>
                    <li class="wow slideInLeft">
                        <div class="timeline-image">
                            <img class="img-circle img-responsive" src="img/about/approval.jpg" alt="">
                        </div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>August 2015</h4>
                                <h4 class="subheading">Secured Ethical Approval to Conduct Clinical Trials</h4>
                            </div>
                            <div class="timeline-body">
                                <p class="text-muted"> In conjunction with our partners, University of Port Harcourt Teaching Hospital (UPTH), we have formally obtained ethical approval to carry out clinical trials of Ubenwa over a period of 8 months. Project will be carried out at Obio Cottage Hospital, the largest maternity centre in Port Harcourt, Nigeria.</p>
                            </div>
                        </div>
                    </li>
                    <li class="timeline-inverted wow slideInRight">
                        <div class="timeline-image">
                            <img class="img-circle img-responsive" src="img/about/ieeebanner.jpg" alt="">
                        </div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>October 2014</h4>
                                <h4 class="subheading">Talks delivered at Silicon Valley and Lausanne</h4>
                            </div>
                            <div class="timeline-body">
                                <p class="text-muted">Charles presented early work on Ubenwa at the Global Humanitarian Technology Conference (GHTC) in Silicon Valley, USA and at UNESCO's Technology for development (Tech4Dev) conference in Lausanne, Switzerland.</p>
                            </div>
                        </div>
                    </li>
                    <li class="wow slideInLeft">
                        <div class="timeline-image">
                            <img class="img-circle img-responsive" src="img/about/1.jpg" alt="">
                        </div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>2012-2014</h4>
                                <h4 class="subheading">Initial research and pilot testing</h4>
                            </div>
                            <div class="timeline-body">
                                <p class="text-muted">We began technical validation to connect newborns cry and Perinatal Asphyxia. During this period, we sought for sample data and iterated on several algorithms for predicting Asphyxia. The result was a unique algorithm.</p>
                            </div>
                        </div>
                    </li>
                    <li class="timeline-inverted wow shake">
                        <div class="timeline-image">
                            <h4>Be Part
                                <br>Of Our
                                <br>Story!</h4>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section id="team" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">The Team</h2>
                </div>
            </div>
            <div class="row">

                <div class="col-sm-3">
                    <div class="team-member">
                        <img src="img/team/Charles_HeadShot.jpg" class="img-responsive img-circle" alt="">
                        <h4>Charles C. Onu </h4>
                        <p class="text-muted">Founder and Principal Innovator</p>
                        <ul class="list-inline social-buttons">
                            <li><a href="https://twitter.com/onucharlesc"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/Charleyon"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li><a href="https://ng.linkedin.com/pub/charles-onu/45/21/663
                                "><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                        <p>
                            Charles carries out research at the intersection of artificial intelligence and biomedical engineering in the <a href="http://rl.cs.mcgill.ca/" target="_blank"> Reasoning and Learning Lab </a>at McGill University. Prior to joining the lab, he worked as a software engineer for 3 years at <a href="http://www.cyphercrescent.com.ng">CypherCrescent</a>.
                        </p>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="team-member">
                        <img src="img/team/ndiomu_headShot.jpg" class="img-responsive img-circle" alt="">
                        <h4>Dr. Eyenimi Ndiomu</h4>
                        <p class="text-muted">Clinical Lead</p>
                        <ul class="list-inline social-buttons">
                            <li><a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                        <p>
                            Eyenimi is a medical doctor and holds a Masters in Public Health from the University of London. He is presently a Clinical fellow at Maidstone and Tunbridge Wells NHS Trust, UK; and has been involved in primary healthcare in Rivers state, Nigeria for over 5 years.
                        </p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="team-member">
                        <img src="img/team/Innocent_HeadShot.jpg" class="img-responsive img-circle" alt="">
                        <h4>Innocent Udeogu</h4>
                        <p class="text-muted">Software Engineering Lead</p>
                        <ul class="list-inline social-buttons">
                            <li><a href="https://twitter.com/innarticle"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li><a href="https://www.facebook.com/udeogu.innocent.k"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li><a href="https://www.linkedin.com/in/innocentudeogu"><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                        <p>Innocent is a software engineer and technology entrepreneur. A graduate of the Meltwater Entrepreneurial School of Technology (MEST), he is the CTO and cofounder of <a href="https://www.oncenout.com" target="_blank">Once'n'out</a> and <a href="http://fisherfoundationafrica.org" target="_blank">Fisher Foundation Africa</a>. He also contributes to several open source projects</p>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="team-member">
                        <img src="img/team/kevin_HeadShot.jpg" class="img-responsive img-circle" alt="">
                        <h4>Urbain Kengni</h4>
                        <p class="text-muted">Business Development Lead</p>
                        <ul class="list-inline social-buttons">
                            <li><a href="https://twitter.com/urbaink2"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li><a href="https://ca.linkedin.com/in/urbain-kengni-mba-1aa47141"><i class="fa fa-linkedin"></i></a>
                            </li>
                        </ul>
                        <p>
                            Urbain has over 12 years’ experience in: business analysis and strategy (Bombardier Aerospace); management consulting (KPMG LLP, Capital Consulting Group); and electrical engineering (LG Electronics). He presently works as a Senior Value Manager at <a href="http://www.workday.com" target="_blank">Workday</a>.
                        </p>
                    </div>
                </div>

            </div>


            <div class="row">
              <div class="col-lg-12 text-center">
                  <h2 class="section-heading">Advisors</h2>
              </div>
          </div>
          <div class="row">
            <div class="col-sm-4">
                <div class="team-member">
                    <!-- <img src="img/team/kevin_HeadShot.jpg" class="img-responsive img-circle" alt=""> -->
                    <h4>Prof. Doina Precup</h4>
                    <p class="text-muted">AI/Technology Advisory</p>
                    <ul class="list-inline social-buttons">
                        <li><a href="https://ca.linkedin.com/in/doina-precup-1ba61314"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                    <p>Professor Precup is a co-director of the Reasoning and Learning Lab at McGill University. She has invested over 20 years in research and innovation in artificial intelligence -especially applied to healthcare problems.</p>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="team-member">
                    <!-- <img src="img/team/kevin_HeadShot.jpg" class="img-responsive img-circle" alt=""> -->
                    <h4>Prof. Edward Alikor</h4>
                    <p class="text-muted">Clinical Advisory</p>
                    <ul class="list-inline social-buttons">
                        <li><a href="https://www.linkedin.com/in/edward-alikor-71252211"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                    <p>Prof. Alikor is a Pediatric Neurologist with over 30 years clinical experience. He is the Director of Medical Research and Training at University of Port Harcourt, Nigeria.</p>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="team-member">
                    <h4>Dr. Peace Opara</h4>
                    <p class="text-muted">Clinical Advisory</p>
                    <ul class="list-inline social-buttons">
                        <li><a href="#"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                    <p>Prof Opara is a consultant neonatologist at the University of Port Harcourt Teaching Hospital. She has over 10 years of experience in teaching and research.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Clients Aside -->
<section id="media">
    <div class="container">
        <div class="row">
           <div class="col-lg-12 text-center">
            <h2 class="section-heading">Media Mentions</h2>
            <br>
        </div>
        <div class="row">
            <div class="col-md-3 col-sm-6">
              <a href="http://jeannesauve.org/scholar/charles-onu/" target="_blank">
                  <img src="img/logos/l-jeanne-sauve-300-en-3.png" class="img-responsive img-centered" alt="">
              </a>
          </div>
          <div class="col-md-3 col-sm-6">
              <a href="http://technologytimes.ng/charles-onu-nigerian-tech-entrepreneur-named-among-global-leaders/" target="_blank">
                  <img src="img/logos/TT-Final-Logo-transparent.png" class="img-responsive img-centered" alt="">
              </a>
          </div>
          <div class="col-md-3 col-sm-6">
              <a href="http://disrupt-africa.com/2015/08/nigerian-techpreneur-selected-for-jeanne-sauve-public-leadership-programme/" target="_blank">
                  <img src="img/logos/disrupt-africa.png" class="img-responsive img-centered" alt="">
              </a>
          </div>
          <div class="col-md-3 col-sm-6">
              <a href="http://www.cp-africa.com/2015/08/11/technology-entrepreneur-charles-onu-to-participate-in-the-jeanne-sauve-public-leadership-program/" target="_blank">
                  <img src="img/logos/cpafrica-logo-and-identity.png" class="img-responsive img-centered" alt="">
              </a>
          </div>
          <div class="col-md-3 col-sm-6">
              <a href="http://www.nigerianbulletin.com/threads/nigerias-charles-onu-named-among-12-prospective-world-leaders.115776/" target="_blank">
                  <img src="img/logos/nigerian-bulletin.png" class="img-responsive img-centered" alt="">
              </a>
          </div>
      </div>
      <div class="row">
          <div class="col-lg-4">
              <a href="http://fisherfoundationafrica.org/blog/2015/07/cofounder-of-fisher-foundation-charles-onu-is-a-jeanne-sauve-fellow" target="_blank">
                  <img src="img/logos/fisher_foundation_logo1.png" class="img-responsive img-centered" alt="">
              </a>
          </div>
          <div class="col-lg-4">
              <a href="http://enactus.org/alumni-named-future-global-leader" target="_blank">
                  <img src="img/logos/enactus.jpg" class="img-responsive img-centered" alt="">
              </a>
          </div>
          <div class="col-lg-4">
              <a href="http://opportunitydesk.org/2015/09/01/charles-onu-from-nigeria-is-the-od-ypom/" target="_blank">
                  <img src="img/logos/Opportunity-Desk.png" class="img-responsive img-centered" alt="">
              </a>
          </div>
      </div>
  </div>
</div>
</section>

<section id="contact">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="section-heading">Contact Us</h2>
                <h3 class="section-subheading text-muted"  style="color:white;">Have something to share? Don't hesitate to drop a message:
                    <p style="margin-top: 25px;"><a href="mailto:ubenwa.team@gmail.com?Subject=Hello">ubenwa.team {at} gmail.com</a></span>
                </h3>
            </div>
        </div>
        <
    </div>
</section>

<footer>
    <div class="container">
        <div class="row">
          <div class="col-md-4">
            <span class="copyright">&copy; Ubenwa Innovations 2017</span>
        </div>
        <div class="col-md-4">
          <ul class="list-inline social-buttons">
              <li><a href="#"><i class="fa fa-twitter"></i></a>
              </li>
              <li><a href="#"><i class="fa fa-facebook"></i></a>
              </li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a>
              </li>
          </ul>
      </div>
          <!--
          <div class="col-md-4">
              <ul class="list-inline quicklinks">
                  <li><a href="#">Privacy Policy</a>
                  </li>
                  <li><a href="#">Terms of Use</a>
                  </li>
              </ul>
          </div>
      -->
  </div>
</div>
</footer>

    <!-- jQuery -->
    <script src="<?php echo base_url('assets/js/jquery.js')?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="<?php echo base_url('assets/js/classie.js')?>"></script>
    <script src="<?php echo base_url('assets/js/cbpAnimatedHeader.js')?>"></script>

    <!-- Contact Form JavaScript -->
    <script src="<?php echo base_url('assets/js/jqBootstrapValidation.js')?>"></script>
    <script src="<?php echo base_url('assets/js/contact_me.js')?>"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url('assets/js/agency.js')?>"></script>
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/script.js')?>"></script>


    <script type='text/javascript'>
      // <![CDATA[

      var frmvalidator  = new Validator("contactus");
      frmvalidator.EnableOnPageErrorDisplay();
      frmvalidator.EnableMsgsTogether();
      frmvalidator.addValidation("name","req","Please provide your name");

      frmvalidator.addValidation("email","req","Please provide your email address");

      frmvalidator.addValidation("email","email","Please provide a valid email address");

      frmvalidator.addValidation("message","maxlen=2048","The message is too long!(more than 2KB!)");

      frmvalidator.addValidation("phone","req","Please provide your phone number");

      // ]]>
      </script>

  </body>

  </html>
